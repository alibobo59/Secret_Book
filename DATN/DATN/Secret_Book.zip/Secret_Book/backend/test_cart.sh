#!/bin/bash
curl -H 'Authorization: Bearer 2|VT22ZPPdZxBTlifXE5Rj0L2ME0j8hyEjmqcTuNAt91fd81a8' \
     -H 'Content-Type: application/json' \
     http://localhost:8000/api/cart