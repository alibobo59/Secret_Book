export { default as adminRoutes } from "./adminRoutes";
export { default as clientRoutes } from "./clientRoutes";
