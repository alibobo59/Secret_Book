// Client routes configuration
const clientRoutes = [
  // Add your client routes here
];

export default clientRoutes;