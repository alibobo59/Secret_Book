<?php

use Illuminate\Support\Facades\Route;

// No web routes needed for API-only application
